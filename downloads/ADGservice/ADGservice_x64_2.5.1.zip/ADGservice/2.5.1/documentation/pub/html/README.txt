This folder contains the media for the API documentation generated from Lisp help strings.
The typical structure is:

CADM-AUTO-DOC-GEN <- package fullname
   | 
   '- images <- folder for images
        |
        '- <image>.png <- image 
