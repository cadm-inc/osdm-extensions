{==============================================================================}
{  ADG generic translator project                                              }
{  Annotator (ME10) Macros for use in outputting 2D Drawings to various formats}
{  Author:  Tom Bower                                                          }
{  Edit Date:  Sat Jan 27, 2007 17:45:27
{                                                                              }
{  TIF                                                                         }
{  HPGL (PLOT)                                                                 }
{  PDF                                                                         }
{                                                                              }
{==============================================================================}
DEFINE Plot_true_color_new
  {This only works with creo color, not cocreate colors}
  TRUE_COLOR_PLOTTING SCREEN_TRANS
	LET Plot_pix_color_option 1
END_DEFINE

{  NOTE: Use same settings as the Plot_black_and_white std. macro              }
DEFINE Adg_set_plot_defaults
PARAMETER Color_mode
LOCAL Unitfactor
  INQ_ENV 6
  LET Unitfactor (INQ 2)
  {Linetype length}
  PLOT_LINETYPE_LENGTH ALL (4 / Unitfactor)
  {Pen transforms}
	IF (Color_mode='TRUE_COLOR')
    Plot_true_color_new
	ELSE_IF (Color_mode='PEN_COLOR')
	  Plot_pen_color
	ELSE_IF (Color_mode='GDI_COLOR')
	  Plot_gdi_color
	ELSE
    Plot_black_and_white
  END_IF
END_DEFINE

{==============================================================================}
{Macro(s) adapted from original PB Print_windchill_X macros                    }
{  Prints the current dwg to TIF format, stored in the TIFF print driver's     }
{  specified location (should be set to *adg-output-dir* filename "ME10.tif")  }
{  Note, plot sheets and driver setup should produce one tif file per drawing  }
DEFINE Pb_print_tiff
PARAMETER Sheet_width
PARAMETER Sheet_height
PARAMETER Tiff_driver
  {define the tiff plotter                                                     }
  {note, on later versions of TIFF driver the name might be 'TIFF-Xchange V3'  }
  {  ...on PB's existing setup it is just 'TIFF'                               }
  PLOTTER_TYPE add MSWINDOW_GDI_PRINTER PRT_DRIVER Tiff_driver 'PB'
    Set_sys_plot_configuration 'jtiff'
    Set_sys_plot_type 'PB'
    Set_sys_plot_filename_delold (TRUE)
    Set_sys_plot_filename_generate (FALSE)
    Set_sys_plot_default ''
    Set_sys_plot_macro_name 'User_plot_macro'
    Set_sys_plot_configuration 'jtiff'
  REQUEST_PRINT_SETUP OFF 
	PLOT_FORMAT Sheet_width Sheet_height
  WIN_PRT_MGR PAPER "Custom size..." ORIENTATION LANDSCAPE COPIES 1
  PLOT_SCALE 1
  PLOT_STOP_ON_ERROR ON {won't produce a plot if error}
  Adg_set_plot_defaults
  TRAP_ERROR
    PLOT SHEETS NORM_VIDEO
  IF (CHECK_ERROR)
    IF (MATCH (ERROR_STR) "Plot does not fit*")
      {then try again with plot scale to fit to page}
      PLOT_SCALE AUTO
      PLOT SHEETS NORM_VIDEO
    END_IF
  END_IF
  END
END_DEFINE

{==============================================================================}
{Macro(s) adapted from original PB Print_windchill_X macros                    }
{  Prints the current dwg to HPGL format to the specified output file          }
{  Note, plot sheets should produce one hpgl file per drawing when >1 sheets   }
DEFINE Pb_print_hpgl
PARAMETER Sheet_width
PARAMETER Sheet_height
PARAMETER Hpgl_file
PARAMETER Sheet
PARAMETER Color_mode
  PLOTTER_TYPE 'HPGL_GENERIC'
  PLOT_DESTINATION DEL_OLD Hpgl_file
  PLOT_CENTER ON
	PLOT_FORMAT Sheet_width Sheet_height
  WIN_PRT_MGR PAPER "Custom size..." ORIENTATION LANDSCAPE COPIES 1
  END
  {PLOT_SCALE 1}
	{use AUTO since this seems to include frame}
	PLOT_SCALE AUTO
  PLOT_STOP_ON_ERROR ON {won't produce a plot if error}
  Adg_set_plot_defaults Color_mode
  TRAP_ERROR
    Adg_plot Sheet
  IF (CHECK_ERROR)
    IF (MATCH (ERROR_STR) "Plot does not fit*")
      {then try again with plot scale to fit to page}
      PLOT_SCALE AUTO
      Adg_plot Sheet
    END_IF
  END_IF
  END
END_DEFINE

{==============================================================================}
{Macro(s) adapted from original PB Print_windchill_X macros                    }
{  Prints the current dwg to PDF format to the specified output file           }
{  Note, plot sheets should produce one hpgl file per drawing when >1 sheets   }
DEFINE Pb_print_pdf
PARAMETER Sheet_width
PARAMETER Sheet_height
PARAMETER Pdf_file
PARAMETER Sheet
PARAMETER Color_mode
  PLOTTER_TYPE 'PDF_GENERIC'
	PLOT_FORMAT Sheet_width Sheet_height
  PLOT_DESTINATION DEL_OLD Pdf_file
  PLOT_CENTER ON
  {WIN_PRT_MGR PAPER Sheet_size ORIENTATION LANDSCAPE COPIES 1}
	WIN_PRT_MGR PAPER "Custom size..." ORIENTATION LANDSCAPE COPIES 1
  END
  {PLOT_SCALE 1}
	{Use AUTO since this seems to include frame}
	PLOT_SCALE AUTO
  PLOT_STOP_ON_ERROR ON {won't produce a plot if error}
  Adg_set_plot_defaults Color_mode
  TRAP_ERROR
	Adg_plot Sheet
  IF (CHECK_ERROR)
    IF (MATCH (ERROR_STR) "Plot does not fit*")
      {then try again with plot scale to fit to page}
      PLOT_SCALE AUTO
	    Adg_plot Sheet
    END_IF
  END_IF
  END
END_DEFINE

DEFINE Adg_plot
  PARAMETER Sheet
	PLOT
	IF (Sheet='')
	  SHEETS
	ELSE
	  PART Sheet
	END_IF
	NO_ASSOC_SELECTION ALL SELECT GLOBAL 
  ALL SUBTRACT GLOBAL INFOS 'DOCU_MARKED_AS_INVISIBLE' CONFIRM 
	IF (Plot_pix_color_option)
	  COLOR_IMG
	ELSE
	  BW_IMG
	END_IF
	NORM_VIDEO
END_DEFINE

{==============================================================================}
{%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%}
{  The following macros are not supported                                }
{  CATEGORY:  Setup                                                      }
{  COMPANY:  W.E.Engineering                                             }
{  AUTHOR: Wim Pragt                                                     }
{  CONTACT OPTION: weeng@deanmoor.nl                                     }
{  VIDEO MODE: Any                                                       }
{  MONITOR RESOLUTION: Any                                               }
{  MACRO TITLE: Save and restore settings                                }
{  DESC: In macros which create objects, it is often necessary to change }
{        the current creation settings (like color, textsize etc.)       }
{        These macros save and restore the most important settings so    }
{        original settings will be back when the creation macro is       }
{        finished.                                                       }
{  MACRO_VERSION: 2.0                                                    }
{  DATE: 29 June 1999                                                    }
{  APPLICATION: ME10 Version 6.0 or later                                }
{  OPSYS: Any                                                            }
{  KEYWORDS: SETTINGS                                                    }

DEFINE Settings_save
INQ_ENV 3
LET Env_geocolor      (INQ 201)
LET Env_geolinetype   (INQ 301)
LET Env_textcolor    (INQ 203)
LET Env_arccolor      (INQ 204)
LET Env_arcltype      (INQ 304)
LET Env_dimcolor      (INQ 205)
LET Env_dimtextcolor  (INQ 206)
INQ_ENV 8
LET Env_textfont     (INQ 301)
INQ_ENV 12
LET Env_textadj      (INQ 3)
LET Env_textlsp      (INQ 4)
LET Env_textrat      (INQ 5)
LET Env_texthig      (INQ 6)
LET Env_textsla      (INQ 7)
LET Env_textfra      (INQ 601)
LET Env_textfil      (INQ 602)
{trap_error}
END_DEFINE

DEFINE Settings_restore

TEXT RGB_COLOR (Env_textcolor) END
TEXT_ADJUST    (Env_textadj)
TEXT_LINESPACE (Env_textlsp)
TEXT_RATIO     (Env_textrat)
TEXT_RATIO     (Env_textrat)
TEXT_SIZE      (Env_texthig)
TEXT_SLANT     (Env_textsla)
TEXT_FRAME     (Env_textfra)
TEXT_FILL      (Env_textfil)
CURRENT_FONT   (Env_textfont)  END

CURRENT_HATCH_PATTERN NONE
HATCH RGB_COLOR             (Env_arccolor)     END
HATCH_LINETYPE              (Env_arcltype)     END

DIM_COLOR RGB_COLOR         (Env_dimcolor)     END
CURRENT_DIM_TEXTS RGB_COLOR (Env_dimtextcolor) END

LINE RGB_COLOR              (Env_geocolor)     END
LINETYPE                    (Env_geolinetype)  END

{DISPLAY_NO_WAIT (CHECK_ERROR)}

END_DEFINE
{%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%}
{macro to add Watermark text to a specified part, whose unique name is passed  }
{  as a string along with the text message.  Text is sized and angled and      }
{  located based on the inquired extents of the part.                          }
DEFINE Adg_add_watermark_text_to_part
  PARAMETER Uniq_partname
  PARAMETER Watermark_text
  PARAMETER Fontname
  PARAMETER Textcolor
  LOCAL Corner_ll
  LOCAL Corner_ur
  LOCAL Textloc
  LOCAL Textheightfactor
  LOCAL Oldpart
	LOCAL Check
  Settings_save
  LET Textheightfactor 0.08
  INQ_PART '.'
  LET Oldpart (INQ 302)
  EDIT_PART Uniq_partname
	TRAP_ERROR
	DELETE 'Adg_watermark'
	LET Check CHECK_ERROR
  INQ_ENV 7
  LET Corner_ll (INQ 101)
  LET Corner_ur (INQ 102)
  {text location is midpoint between corners}
  LET Textloc ((Corner_ll + Corner_ur)/2)
  {text angle is defined to be parallel to the diagonal}
  TEXT_ANGLE Corner_ll Corner_ur
  {Text height is defined as a fixed percentage of the length of the diagonal}
  { -- was empirically determined by trial and error to be usable            }
  TEXT_SIZE (Textheightfactor * (LEN (Corner_ur - Corner_ll)))
  {Text fill always off so watermark doesn't intrude too much}
  TEXT_FILL OFF
  {Set Text Adjust to be 5 (center of text)}
  TEXT_ADJUST 5
  {Set current Font for text}
  CURRENT_FONT Fontname
  {Now add the text}
	INIT_SUBPART 'Adg_watermark'
  TEXT Textcolor Watermark_text Textloc END
  {Clean up and leave.}
  Settings_restore
  EDIT_PART Oldpart
END_DEFINE
{%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%}

