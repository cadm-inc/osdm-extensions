﻿function blazorGetTimezoneOffset() {
    return new Date().getTimezoneOffset();
}