This folder contains the media for the API documentation generated from Lisp help strings.
The typical structure is:

resources
    |
    +- Build.json <- documentation build configuration
    |
    '- CADM-TOOLS <- package fullname
            | 
            '- images <- folder for images
                 |
                 '- <image>.png <- image 
    