
function update_manifest() {

    var scripts = document.getElementsByTagName('script');

    var json="js/manifest.js";
    // find self
    for (var i in scripts) {
        var src = scripts[i].src
        if (src.endsWith("manifest.js")) {
            // json is right next to self
            json = src.replace(".js",".json");
            break
        }
    }

    // load the manifest and update manifest data on page
    var req = new XMLHttpRequest();
    req.open("GET",json,true); // async

    req.onload = function (e) {
        if (req.readyState === 4 && req.status === 200) {
            var manifest = JSON.parse(req.responseText);

            for (var key in manifest) {
                var tag = document.getElementsByClassName(key);
                for (var i in tag) {
                     tag[i].outerText = manifest[key];
                }
            }
        }
    }

    req.send();
}

if (window.addEventListener) { // W3C standard
    window.addEventListener('load', update_manifest, false); // NB **not** 'onload'
}
else if (window.attachEvent) { // Microsoft
    window.attachEvent('onload', update_manifest);
}

